# DebugHub v1.2.1 — rollout to MyDapp + Faucet / BlockpotDAO / MessageBoard

TimbSwap is already on this SDK (it self-hosts its own copy). This package brings
the **other apps** up to the same version and turns on their telemetry.

Two independent things are broken for the other apps today, and you need **both**:

1. **They load an old SDK.** All three load
   `0xtimberzx.github.io/MyDapp/debughub/sdk/debugger.js`, so they get whatever
   MyDapp serves. Until MyDapp is updated they miss the v1.2.x network sink *and*
   the v1.2.1 wallet-detect fix.
2. **They have no sink config.** Per `reference/NOTES.md`: *"only TimbSwap
   currently carries supabaseUrl/supabaseKey in its config, so only TimbSwap
   populates the sink."* Even a fixed SDK stays localStorage-only without it.

No backend work is needed — RLS already whitelists all five app names.

---

## What's in here

```
debughub-v1.2.1/
├── sdk/debugger.js        → copy to MyDapp/debughub/sdk/debugger.js
├── hub/app.js             → copy to MyDapp/debughub/app.js   (the READ path)
└── reference/
    ├── schema.sql         → the table + RLS, already applied (review only)
    └── NOTES.md           → operational gotchas
```

## What changed in 1.2.1 (vs the 1.2.0 draft)

- **`Wallet Detect` no longer false-positives.** It used to log a *security
  failure* whenever a wallet extension existed but hadn't exposed an account —
  i.e. every normal page load before the user connects. On TimbSwap that was
  **76 failures and 0 passes**. Now it only fires if the account genuinely never
  turns up.
- **`Wallet Dropped` is `pass`, not `fail`.** It fires on a deliberate
  disconnect/lock — lifecycle, not a fault.
- **`SDK_VERSION` is `"1.2.1"`**, so you can tell pre/post-fix events apart via
  the `sdkVersion` field.

---

## Step 1 — MyDapp (serves the SDK + hosts the hub)

```bash
cp sdk/debugger.js  <MyDapp>/debughub/sdk/debugger.js
cp hub/app.js       <MyDapp>/debughub/app.js          # only if you want the hub reading Supabase
```

Then **bump the cache-buster in every page that loads the SDK** — GitHub Pages
caches assets, and a stale `?v=` is exactly what made the first rollout appear to
do nothing:

```bash
cd <MyDapp>
grep -rl 'debughub/sdk/debugger.js' --include=*.html . \
  | xargs sed -i 's|debugger\.js?v=[^"]*|debugger.js?v=1.2.1|g'
grep -rn 'debugger.js?v=' --include=*.html . | head    # verify
```

## Step 2 — each app's config (Faucet, BlockpotDAO, MessageBoard)

Add the two sink fields to the existing `DEBUGHUB_CONFIG`. **Only `appName`
changes per app** — it must match the RLS allowlist exactly (case-sensitive):
`Faucet` · `BlockpotDAO` · `MessageBoard`.

```js
window.DEBUGHUB_CONFIG = {
  appName:     "Faucet",              // ← BlockpotDAO / MessageBoard for the others
  supabaseUrl: "https://ipyfodnidwsdvwqrcjrl.supabase.co",
  supabaseKey: "sb_publishable_yg4wjMwvGrlf5C9vqs2nkw_Hfks0Ux9"
};
```

The anon key is **public by design** — RLS is the security boundary, so it is fine
in client JS. Do not treat it as a secret; do treat the RLS policies as the
surface that matters.

Placement: the SDK reads these **lazily at send time**, so setting them in a
`config.js` that loads *after* the `<script src=...debugger.js>` tag is fine —
that's how TimbSwap does it. Setting them inline before the tag works too. What
does **not** work is setting `{ appName }` alone somewhere that overwrites a
fuller config later.

## Step 3 — verify

Load a page, connect a wallet, do one action, then:

```sql
select app, count(*) events, max(created_at) latest
from public.debughub_events
group by app order by events desc;
```

Each app should appear within a minute. If one is missing:

- `42501` on insert → the `appName` string doesn't match the RLS allowlist.
- Nothing at all → the SDK is still the cached old one (redo the `?v=` bump), or
  the config was overwritten after load.
- Check `sdkVersion` on new rows — it should read `1.2.1`.

---

## Extracting this on GitHub Codespaces

Codespaces has no "upload" button in the editor toolbar, so use one of these:

**A. Drag and drop (easiest).** Open the Codespace in the browser, then drag
`debughub-v1.2.1.tar.gz` from your desktop onto the **file explorer pane** on the
left. It uploads into whatever folder you drop it on. Then in the terminal:

```bash
tar -xzf debughub-v1.2.1.tar.gz
ls debughub-v1.2.1
```

**B. From a terminal, if the file is on your machine.** Use the `gh` CLI's
Codespaces SSH support:

```bash
gh codespace cp -e debughub-v1.2.1.tar.gz remote:/workspaces/<repo>/
```

**C. Skip the tarball entirely.** Everything here is plain text — you can also
just open `sdk/debugger.js` locally, copy the contents, and paste into the file
in Codespaces. For a single-file change that is often faster than uploading.

Notes:
- If `tar` complains, confirm the download completed: `ls -l *.tar.gz` should show
  ~30 KB, not a few hundred bytes.
- Codespaces is Linux, so the `sed -i` commands above work as written (on macOS
  you'd need `sed -i ''`).
- Nothing here needs `npm install` — it is vanilla JS and SQL.
